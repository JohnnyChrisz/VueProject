<template>
  <div
    class="flex min-h-screen flex-row"
    :class="{ 'dark-mode': darkMode }">
    <button @click="toggleDarkMode" class="absolute top-4 right-4 p-2 rounded-md bg-indigo-600 text-white">{{ darkMode ? 'Light Mode' : 'Dark Mode' }}</button>
    <div class="left bg-slate-200 flex justify-center" style="width: 40%; align-items: center; display:flexbox">
      <div class="" align="center">
        <img class=" p-2" style="border-radius: 50%; width: 150px; height: 150px;" src="D:\VueProject\PhoneVue\picture\ChriszPic.jpg" alt="">
        <h1 class=" text-black font-serif">WELCOME TO <span class="text-indigo-600">CHRISZ</span> SHOP</h1>
        <p class=" font-sans text-black" style="font-size: small;">Everything Doesn't Last Forever</p>
      </div>
    </div>
    <div class="right bg-slate-300" style="width: 60%;">
      <h1 class="two" style="margin-top: 10vh; padding: 20px;">Smart Choices, Happy Drives: Get More Car for Your Money at <span class="text-indigo-600">CHRISZ</span> SHOP.</h1>
    </div>  
  </div>
</template>

<script>
export default {
  data() {
    return {
      darkMode: false,
    };
  },
  methods: {
    toggleDarkMode() {
      this.darkMode = !this.darkMode;
    },
  },
};
</script>

<style scoped>
/* Light mode styles */
.light-mode, .light-mode aside {
  background-color: #ffffff;
  color: #000000;
}

/* Dark mode styles */
.dark-mode, .dark-mode p, .dark-mode h1, .dark-mode .left {
  color: #ffffff;
  background-color: #333333;  
}
.dark-mode .right, .dark-mode .two{
  color: #ffffff;
  background-color: #4b4b4b;
}
</style>
